class KhmerChessGame:
    def __init__(self):
        self.board = [["-" for _ in range(8)] for _ in range(8)]
        self.player_turn = "Max"
        self.status = None
        self.ranks_to_rows = {"a": 0, "b": 1, "c": 2, "d": 3, "e": 4, "f": 5, "g": 6, "h": 7}
        self.rows_to_ranks = {v: k for k, v in self.ranks_to_rows.items()}
        self.files_to_cols = {"1": 0, "2": 1, "3": 2, "4": 3, "5": 4, "6": 5, "7": 6, "8": 7}
        self.cols_to_files = {v: k for k, v in self.files_to_cols.items()}
        self.move_log = []
        self.init_board()

    def init_board(self):
        self.board[1] = ["P"] * 8
        self.board[6] = ["p"] * 8
        self.board[0][4] = "K"
        self.board[7][4] = "k"

    def switchPlayer(self):
        self.player_turn = "Min" if self.player_turn == "Max" else "Max"

    def checkPlayer(self, piece):
        return "Min" if piece.islower() else "Max"

    def moveByNotation(self, notation):
        try:
            origin_row = self.ranks_to_rows[notation[0]]
            origin_col = self.files_to_cols[notation[1]]
            destination_row = self.ranks_to_rows[notation[2]]
            destination_col = self.files_to_cols[notation[3]]
            return self.moveByIndex(origin_row, origin_col, destination_row, destination_col)
        except:
            return False

    def moveByIndex(self, origin_row, origin_col, dest_row, dest_col):
        if self.status == "gameover":
            return False
        piece = self.board[origin_row][origin_col]
        if piece == "-" or self.checkPlayer(piece) != self.player_turn:
            return False
        self.board[dest_row][dest_col] = piece
        self.board[origin_row][origin_col] = "-"
        if piece.lower() == "k":
            self.status = "gameover"
        self.switchPlayer()
        return True