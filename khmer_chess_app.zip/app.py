from flask import Flask, render_template, request, jsonify
from game_engine import KhmerChessGame
from ai_engine import KhmerChessAI

app = Flask(__name__)
game = KhmerChessGame()
ai = KhmerChessAI(game)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/new_game")
def new_game():
    global game, ai
    game = KhmerChessGame()
    ai = KhmerChessAI(game)
    return jsonify({"board": game.board, "turn": game.player_turn})

@app.route("/player_move", methods=["POST"])
def player_move():
    data = request.get_json()
    move = data.get("move")
    result = game.moveByNotation(move)
    if result and game.status != "gameover":
        ai.aiMove(3, game.player_turn)
    return jsonify({"board": game.board, "turn": game.player_turn, "status": game.status})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)