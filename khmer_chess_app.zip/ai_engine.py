import random

class KhmerChessAI:
    def __init__(self, game):
        self.game = game
        self.piece_score = {"P": 1, "p": -1, "K": 100, "k": -100}

    def aiMove(self, depth, player):
        valid_moves = self._get_all_moves(player)
        if not valid_moves:
            return False
        move = random.choice(valid_moves)
        return self.game.moveByIndex(*move)

    def _get_all_moves(self, player):
        moves = []
        for r in range(8):
            for c in range(8):
                piece = self.game.board[r][c]
                if piece != "-" and self.game.checkPlayer(piece) == player:
                    for dr in [-1, 0, 1]:
                        for dc in [-1, 0, 1]:
                            if dr == 0 and dc == 0:
                                continue
                            nr, nc = r + dr, c + dc
                            if 0 <= nr < 8 and 0 <= nc < 8:
                                target = self.game.board[nr][nc]
                                if target == "-" or self.game.checkPlayer(target) != player:
                                    moves.append((r, c, nr, nc))
        return moves