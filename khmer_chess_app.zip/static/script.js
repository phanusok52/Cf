
let selected = null;
let boardData = [];

function renderBoard(board) {
    const boardDiv = document.getElementById("board");
    boardDiv.innerHTML = "";
    boardData = board;
    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
            const cell = document.createElement("div");
            cell.className = "cell " + ((r + c) % 2 === 0 ? "light" : "dark");
            cell.dataset.row = r;
            cell.dataset.col = c;
            cell.textContent = board[r][c] !== "-" ? board[r][c] : "";
            cell.onclick = () => selectCell(r, c);
            boardDiv.appendChild(cell);
        }
    }
}

function selectCell(r, c) {
    if (selected) {
        const move = posToNotation(selected.r, selected.c) + posToNotation(r, c);
        fetch("/player_move", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ move })
        })
        .then(res => res.json())
        .then(data => renderBoard(data.board));
        selected = null;
    } else {
        selected = { r, c };
    }
}

function posToNotation(r, c) {
    const files = "abcdefgh";
    const ranks = "12345678";
    return files[r] + ranks[c];
}

function newGame() {
    fetch("/new_game")
    .then(res => res.json())
    .then(data => renderBoard(data.board));
}

window.onload = newGame;
